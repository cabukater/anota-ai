import { Component } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent {
   title: string ='Teste de desenvolvedora Front-End - Anota AI';
   subTitle : string = 'Camila Assis'
}
